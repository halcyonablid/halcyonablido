TRUNCATE typecho_meting;
